package com.example.danielm

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btn1 =findViewById<Button>(R.id.button)

        var edit1 = findViewById<EditText>(R.id.editTextText)
        var edit2 = findViewById<EditText>(R.id.editTextText2)
        val textV = findViewById<TextView>(R.id.textview)

        val spine = findViewById<Spinner>(R.id.spinner)

        val intent =Intent(applicationContext,ActivityList::class.java)

        var bundel = Bundle ()
        bundel.putString("Nombre","Daniel mejia")
        bundel.putInt("Edad", 21)
        intent.putExtra( "info",bundel)
        var conti= 0



        Toast.makeText(baseContext,spine.onItemSelectedListener.toString(),Toast.LENGTH_LONG).show()
        btn1.setOnClickListener () {
            //var temp1 = edit2.toString().toFloat().div(100)
           // textV.text=edit1.toString().toFloat().times(temp1).toString()


           // intent.putExtra( "msj", "esto es de otra pantalla1 ")
            startActivity(intent)
            conti ++
            Log.e("app_p1",conti.toString())


        }

        class SpinnerActivity : Activity(), AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
                // An item is selected. You can retrieve the selected item using
                // parent.getItemAtPosition(pos).
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Another interface callback.
            }
        }



    }
}