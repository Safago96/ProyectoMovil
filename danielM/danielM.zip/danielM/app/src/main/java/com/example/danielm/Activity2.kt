package com.example.danielm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        val text1 = findViewById<TextView>(R.id.textView)
        val text2  =findViewById<TextView>(R.id.textView2)
        val infoRecivida = intent.getBundleExtra("info")
        text1.text = infoRecivida?.getString("Nombre")
        text2.text = infoRecivida?.getInt("Edad").toString()

    val web= findViewById<WebView>(R.id.web)
        web.webViewClient= WebViewClient()
        web.loadUrl("https://es.wikipedia.org/wiki/How_to_Sell_Drugs_Online_(Fast)")




    }
}