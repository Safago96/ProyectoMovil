package com.example.danielm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class ActivityWeb : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)



        val web= findViewById<WebView>(R.id.web2)
        web.webViewClient= WebViewClient()
        web.loadUrl("https://es.wikipedia.org/wiki/How_to_Sell_Drugs_Online_(Fast)")





    }
}